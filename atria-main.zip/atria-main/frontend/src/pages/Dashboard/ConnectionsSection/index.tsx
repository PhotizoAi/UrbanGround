import { useState } from 'react';
import { Avatar } from '@mantine/core';
import { useNavigate } from 'react-router-dom';
import { useMediaQuery } from '@mantine/hooks';
import { useCreateDirectMessageThreadMutation } from '@/app/features/networking/api';
import { useOpenThread } from '@/shared/hooks/useOpenThread';
import { notifications } from '@mantine/notifications';
import { IconMessage } from '@tabler/icons-react';
import { Button } from '@/shared/components/buttons';
import { ButtonLoader } from '@/shared/components/loading';
import type { DashboardConnection } from '../index';
import styles from './styles/index.module.css';

type ConnectionsSectionProps = {
  connections: DashboardConnection[] | null;
};

type ThreadResponse = {
  thread_id?: number;
  id?: number;
  data?: {
    thread_id?: number;
    id?: number;
  };
};

export const ConnectionsSection = ({ connections }: ConnectionsSectionProps) => {
  const navigate = useNavigate();
  const openThread = useOpenThread();
  const isMobile = useMediaQuery('(max-width: 768px)');
  const [createThread] = useCreateDirectMessageThreadMutation();
  const [messagingUserId, setMessagingUserId] = useState<number | null>(null);

  const getInitials = (name: string | null): string => {
    if (!name) return '?';
    const parts = name.split(' ');
    if (parts.length >= 2 && parts[0] && parts[1]) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  const getAvatarGradient = (index: number): string => {
    const gradients = [
      'linear-gradient(45deg, #EC4899, #F472B6)',
      'linear-gradient(45deg, #06B6D4, #0891B2)',
      'linear-gradient(45deg, #F59E0B, #EAB308)',
      'linear-gradient(45deg, #10B981, #059669)',
      'linear-gradient(45deg, #8B5CF6, #A855F7)',
    ];
    return gradients[index % gradients.length] ?? 'linear-gradient(45deg, #EC4899, #F472B6)';
  };

  const handleMessage = async (userId: number, userName: string) => {
    setMessagingUserId(userId);
    try {
      const result = (await createThread(userId).unwrap()) as ThreadResponse;
      const threadId = result.thread_id || result.id || result.data?.thread_id || result.data?.id;

      if (threadId) {
        openThread(threadId);
        // Only show notification on desktop - mobile makes it obvious with full screen
        if (!isMobile) {
          notifications.show({
            title: 'Success',
            message: `Started conversation with ${userName}`,
            color: 'green',
          });
        }
      } else {
        throw new Error('Failed to get thread ID');
      }
    } catch (error) {
      console.error('Failed to create/open thread:', error);
      notifications.show({
        title: 'Error',
        message: 'Failed to start conversation. Please try again.',
        color: 'red',
      });
    } finally {
      setMessagingUserId(null);
    }
  };

  return (
    <section className={styles.dashboardSection}>
      <div className={styles.sectionHeader}>
        <h2 className={styles.sectionTitle}>Recent Connections</h2>
        <Button variant='secondary' onClick={() => navigate('/app/network')}>
          View All
        </Button>
      </div>

      {connections && connections.length > 0 ?
        <div className={styles.connectionsList}>
          {connections.map((connection, index) => (
            <div key={connection.id} className={styles.connectionItem}>
              <Avatar
                src={connection.user.avatar_url}
                alt={connection.user.display_name || connection.user.username}
                size={35}
                radius={6}
                className={styles.connectionAvatar ?? ''}
                styles={{
                  placeholder: {
                    background: getAvatarGradient(index),
                    color: 'white',
                    fontWeight: 600,
                    fontSize: '0.9rem',
                  },
                }}
              >
                {getInitials(connection.user.display_name || connection.user.username)}
              </Avatar>
              <div className={styles.connectionInfo}>
                <div
                  className={styles.connectionName}
                  onClick={() => navigate(`/app/users/${connection.user.id}`)}
                  style={{ cursor: 'pointer' }}
                >
                  {connection.user.display_name || connection.user.username}
                </div>
                <div className={styles.connectionRole}>
                  {connection.title && connection.company ?
                    `${connection.title} at ${connection.company}`
                  : connection.title || connection.company || ''}
                </div>
              </div>
              {messagingUserId === connection.user.id ?
                <div className={styles.messageIcon}>
                  <ButtonLoader />
                </div>
              : <IconMessage
                  size={26}
                  className={styles.messageIcon}
                  onClick={() =>
                    handleMessage(
                      connection.user.id,
                      connection.user.display_name || connection.user.username,
                    )
                  }
                />
              }
            </div>
          ))}
        </div>
      : <div className={styles.emptyState}>
          <p>No connections yet. Start networking at events!</p>
          <Button variant='primary' onClick={() => navigate('/app/events')}>
            Find Events
          </Button>
        </div>
      }
    </section>
  );
};
